import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QFileDialog, QVBoxLayout, QWidget, QStatusBar, QMessageBox, QLineEdit, QPushButton, QListWidget, QHBoxLayout, QInputDialog, QToolBar, QSizePolicy
from PySide6.QtGui import QAction
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtCore import QLocale, QTranslator, QUrl
import markdown2
import os
import subprocess

class MarkdownReader(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.current_file = None
        self.translator = QTranslator()

    def initUI(self):
        self.setWindowTitle('Markdown Reader')
        self.setGeometry(100, 100, 800, 600)
        
        # 启用拖拽支持
        self.setAcceptDrops(True)

        # 创建自定义工具栏作为菜单栏和搜索栏
        self.toolbar = QToolBar()
        self.toolbar.setMovable(False)
        self.addToolBar(self.toolbar)
        
        # 自定义菜单按钮
        fileButton = QPushButton('文件')
        fileButton.clicked.connect(self.showFileMenu)
        self.toolbar.addWidget(fileButton)
        
        # 标签按钮
        tagButton = QPushButton('标签')
        tagButton.clicked.connect(self.showTagMenu)
        self.toolbar.addWidget(tagButton)
        
        # 添加伸缩项将搜索控件推到右边
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.toolbar.addWidget(spacer)
        
        # 搜索控件
        self.searchInput = QLineEdit()
        self.searchInput.setPlaceholderText('搜索...')
        self.searchInput.returnPressed.connect(self.searchText)
        self.toolbar.addWidget(self.searchInput)
        
        searchButton = QPushButton('搜索')
        searchButton.clicked.connect(self.searchText)
        self.toolbar.addWidget(searchButton)

        # 主布局
        layout = QVBoxLayout()

        # 内容显示区域
        self.webView = QWebEngineView()
        layout.addWidget(self.webView, 1)  # 设置伸缩因子为1，使其占据主要空间

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)
        
        # 添加状态栏
        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.showMessage('就绪')
        
    def openFile(self, fname=None):
        if not fname:
            fname, _ = QFileDialog.getOpenFileName(self, '打开Markdown文件', '', 'Markdown文件 (*.md)')
        if fname:
            self.current_file = fname
            self.statusBar.showMessage(f'正在打开: {os.path.basename(fname)}...')
            self.setEnabled(False)  # 禁用界面以显示正在加载
            from PySide6.QtCore import QThread, Signal
            
            class FileLoaderThread(QThread):
                contentLoaded = Signal(str)
                progress = Signal(str)
                
                def __init__(self, file_path):
                    super().__init__()
                    self.file_path = file_path
                
                def run(self):
                    try:
                        self.progress.emit('正在读取文件...')
                        # Remove explicit 'where pandoc' call, assume pandoc is in PATH
                        # pandoc_check_command = ['where', 'pandoc']
                        # pandoc_path_result = subprocess.run(pandoc_check_command, creationflags=subprocess.CREATE_NO_WINDOW, capture_output=True, text=True, encoding='utf-8', errors='ignore')
                        # pandoc_path = pandoc_path_result.stdout.strip()
                        
                        # if not pandoc_path:
                        #     raise FileNotFoundError # This will now be caught by the direct pandoc call if not found
                        
                        with open(self.file_path, 'r', encoding='utf-8') as file:
                            content = file.read()
                        self.progress.emit('正在转换Markdown为HTML...')
                        html_content = markdown2.markdown(content, extras=['tables', 'fenced-code-blocks', 'mathjax'])
                        mathjax_html = """
                        <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.7/MathJax.js?config=TeX-AMS-MML_HTMLorMML"></script>
                        <script type="text/x-mathjax-config">
                            MathJax.Hub.Config({
                                tex2jax: {
                                    inlineMath: [['$','$'], ['\\(','\\)']],
                                    displayMath: [['$$','$$'], ['\\[','\\]']],
                                    processEscapes: true
                                }
                            });
                        </script>
                        """
                        html_content = f"<html><head>{mathjax_html}</head><body>{html_content}</body></html>"
                        self.contentLoaded.emit(html_content)
                    except Exception as e:
                        self.contentLoaded.emit(f"<html><body><h1>加载文件出错: {str(e)}</h1></body></html>")
            
            self.loader_thread = FileLoaderThread(fname)
            self.loader_thread.contentLoaded.connect(lambda html: self.webView.setHtml(html, QUrl.fromLocalFile(fname)))
            self.loader_thread.progress.connect(self.statusBar.showMessage)
            self.loader_thread.finished.connect(lambda: [self.statusBar.showMessage(f'已打开: {os.path.basename(fname)}'), self.setEnabled(True)])
            self.loader_thread.start()

    def showFileMenu(self):
        from PySide6.QtWidgets import QMenu
        menu = QMenu(self)
        openAction = QAction('打开', self)
        openAction.triggered.connect(self.openFile)
        menu.addAction(openAction)
        
        saveDocxAction = QAction('保存为DOCX', self)
        saveDocxAction.triggered.connect(lambda: self.convertTo('docx'))
        menu.addAction(saveDocxAction)
        
        saveHtmlAction = QAction('保存为HTML', self)
        saveHtmlAction.triggered.connect(lambda: self.convertTo('html'))
        menu.addAction(saveHtmlAction)
        
        menu.exec(self.mapToGlobal(self.toolbar.geometry().bottomLeft()))

    def searchText(self):
        search_term = self.searchInput.text()
        if search_term:
            self.webView.findText(search_term)

    def showTagMenu(self):
        from PySide6.QtWidgets import QMenu
        menu = QMenu(self)
        addTagAction = QAction('添加标签', self)
        addTagAction.triggered.connect(self.addTag)
        menu.addAction(addTagAction)
        
        viewTagsAction = QAction('查看标签', self)
        viewTagsAction.triggered.connect(self.viewTags)
        menu.addAction(viewTagsAction)
        
        deleteTagAction = QAction('删除标签', self)
        deleteTagAction.triggered.connect(self.deleteTag)
        menu.addAction(deleteTagAction)
        
        menu.exec(self.mapToGlobal(self.toolbar.geometry().bottomLeft()))

    def searchPrevious(self):
        search_term = self.searchInput.text()
        if not search_term:
            QMessageBox.warning(self, '搜索', '请输入搜索词', QMessageBox.Ok)
            return
    
        # 确保先进行向前搜索
        if not hasattr(self, 'last_search_term') or self.last_search_term != search_term:
            self.searchText()
    
        from PySide6.QtWebEngineWidgets import QWebEnginePage
        flags = QWebEnginePage.FindFlag.FindBackward
        self.webView.findText(search_term, flags, lambda found: self.statusBar.showMessage('找到上一个匹配项' if found else '未找到上一个匹配项'))
        self.last_search_term = search_term
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            # 检查拖拽位置是否在webView区域
            pos = event.position().toPoint()
            web_view_rect = self.webView.geometry()
            if web_view_rect.contains(pos):
                event.accept()  # 在webView区域接受拖拽
            else:
                event.ignore()  # 其他区域显示无效状态
        else:
            event.ignore()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            file_path = url.toLocalFile()
            if file_path.endswith('.md'):
                self.openFile(file_path)
                break

    def addTag(self):
        tag, ok = QInputDialog.getText(self, '添加标签', '输入标签名称:')
        if ok and tag:
            if not hasattr(self, 'tags'):
                self.tags = {}
            if self.current_file:
                if self.current_file not in self.tags:
                    self.tags[self.current_file] = []
                # 获取当前滚动位置
                self.webView.page().runJavaScript("window.scrollY", 0, lambda result: self.storeTagWithPosition(tag, result))
            else:
                self.statusBar.showMessage('请先打开一个文件')

    def viewTags(self):
        if not hasattr(self, 'tags') or not self.tags:
            QMessageBox.information(self, '标签', '没有标签', QMessageBox.Ok)
            return
        
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QListWidget, QPushButton
        dialog = QDialog(self)
        dialog.setWindowTitle('标签列表')
        layout = QVBoxLayout()
        
        listWidget = QListWidget()
        for file, tags in self.tags.items():
            for tag_info in tags:
                if isinstance(tag_info, dict):
                    tag_name = tag_info.get('name', '未知标签')
                    position = tag_info.get('position', '未知位置')
                    listWidget.addItem(f"{os.path.basename(file)}: {tag_name} (位置: {position})")
                else:
                    listWidget.addItem(f"{os.path.basename(file)}: {tag_info}")
        layout.addWidget(listWidget)
        
        # 双击列表项跳转到标签位置
        listWidget.itemDoubleClicked.connect(lambda item: self.jumpToTagPosition(item, dialog))
        
        closeButton = QPushButton('关闭')
        closeButton.clicked.connect(dialog.close)
        layout.addWidget(closeButton)
        
        jumpButton = QPushButton('跳转到标签位置')
        jumpButton.clicked.connect(lambda: self.jumpToTagPosition(listWidget.currentItem(), dialog))
        layout.addWidget(jumpButton)
        
        dialog.setLayout(layout)
        dialog.exec()

    def storeTagWithPosition(self, tag, scrollY):
        tag_info = {'name': tag, 'position': scrollY}
        if tag_info not in self.tags[self.current_file]:
            self.tags[self.current_file].append(tag_info)
            self.statusBar.showMessage(f'已添加标签 "{tag}" 到当前文件，位置: {scrollY}')
        else:
            self.statusBar.showMessage(f'标签 "{tag}" 已存在于当前文件')

    def jumpToTagPosition(self, item, dialog):
        if item:
            text = item.text()
            start_idx = text.find('(位置: ')
            if start_idx != -1:
                position_str = text[start_idx + 7:].rstrip(')')
                try:
                    position = int(position_str)
                    self.webView.page().runJavaScript(f"window.scrollTo(0, {position});", 0, lambda _: None)
                    dialog.close()
                    self.statusBar.showMessage(f'已跳转到标签位置: {position}')
                except ValueError:
                    self.statusBar.showMessage('无法解析标签位置')
            else:
                self.statusBar.showMessage('无法找到标签位置信息')
        else:
            self.statusBar.showMessage('请选择一个标签')

    def convertTo(self, format):
        if not self.current_file:
            return
        
        # 获取当前文件的文件名（不包括路径）
        base_name = os.path.basename(self.current_file)
        # 去掉扩展名
        base_name_without_ext = os.path.splitext(base_name)[0]
        # 设置默认保存文件名
        default_save_name = f"{base_name_without_ext}.{format}"
        
        output_file, _ = QFileDialog.getSaveFileName(self, f'保存为{format.upper()}', default_save_name, f'{format.upper()}文件 (*.{format})')
        if output_file:
            from PySide6.QtCore import QThread, Signal
            
            class ConvertThread(QThread):
                conversionFinished = Signal(str)
                conversionError = Signal(str)
                
                def __init__(self, input_file, output_file, format_type, resource_dir):
                    super().__init__()
                    self.input_file = input_file
                    self.output_file = output_file
                    self.format_type = format_type
                    self.resource_dir = resource_dir
                
                def run(self):
                    try:
                        # Directly call pandoc, assuming it's in the PATH
                        # The FileNotFoundError for pandoc will now be caught directly by subprocess.run if pandoc is not found
                        command = ['pandoc', self.input_file, '-o', self.output_file, '--embed-resources', '--standalone', f'--resource-path={self.resource_dir}']
                        # Use DETACHED_PROCESS and redirect all I/O to DEVNULL for maximum hiddenness
                        result = subprocess.run(command, 
                                                creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS,
                                                stdin=subprocess.DEVNULL,
                                                stdout=subprocess.DEVNULL,
                                                stderr=subprocess.DEVNULL,
                                                capture_output=False, # capture_output should be False when redirecting stdout/stderr
                                                text=False, # text should be False when redirecting to DEVNULL
                                                encoding='utf-8', 
                                                errors='ignore')
                        
                        # Since output is redirected to DEVNULL, we can't capture it to check for errors via result.stderr
                        # Instead, we rely solely on the return code.
                        if result.returncode == 0:
                            self.conversionFinished.emit(f'转换完成: {os.path.basename(self.input_file)} -> {os.path.basename(self.output_file)}')
                        else:
                            # If pandoc returns a non-zero exit code, it might indicate an issue.
                            # Without capturing stderr, we can only provide a generic error message based on the return code.
                            self.conversionError.emit(f'转换失败: Pandoc exited with code {result.returncode}')
                    except FileNotFoundError:
                        self.conversionError.emit('Pandoc未安装')
                    except Exception as e:
                        self.conversionError.emit(f'转换过程中发生错误: {str(e)}')
            
            self.statusBar.showMessage(f'转换中: {base_name} -> {format.upper()}')
            self.setEnabled(False)  # 禁用界面以显示正在转换
            resource_dir = os.path.dirname(self.current_file)
            self.convert_thread = ConvertThread(self.current_file, output_file, format, resource_dir)
            self.convert_thread.conversionFinished.connect(lambda msg: [self.statusBar.showMessage(msg), self.setEnabled(True)])
            self.convert_thread.conversionError.connect(lambda err: [self.showConversionError(err, format), self.setEnabled(True)])
            self.convert_thread.start()
    
    def deleteTag(self):
        if not hasattr(self, 'tags') or not self.tags or not self.current_file or self.current_file not in self.tags:
            QMessageBox.information(self, '删除标签', '当前文件没有标签', QMessageBox.Ok)
            return
        
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QListWidget, QPushButton
        dialog = QDialog(self)
        dialog.setWindowTitle('删除标签')
        layout = QVBoxLayout()
        
        listWidget = QListWidget()
        for tag_info in self.tags[self.current_file]:
            if isinstance(tag_info, dict):
                tag_name = tag_info.get('name', '未知标签')
                position = tag_info.get('position', '未知位置')
                listWidget.addItem(f"{tag_name} (位置: {position})")
            else:
                listWidget.addItem(tag_info)
        layout.addWidget(listWidget)
        
        deleteButton = QPushButton('删除')
        deleteButton.clicked.connect(lambda: self.removeTag(listWidget.currentItem(), dialog))
        layout.addWidget(deleteButton)
        
        closeButton = QPushButton('关闭')
        closeButton.clicked.connect(dialog.close)
        layout.addWidget(closeButton)
        
        dialog.setLayout(layout)
        dialog.exec()

    def removeTag(self, item, dialog):
        if item:
            text = item.text()
            start_idx = text.find('(位置: ')
            tag_name = text.split(' (位置: ')[0] if start_idx != -1 else text
            for tag_info in self.tags[self.current_file][:]:
                if isinstance(tag_info, dict) and tag_info.get('name') == tag_name:
                    self.tags[self.current_file].remove(tag_info)
                    self.statusBar.showMessage(f'已删除标签 "{tag_name}"')
                    dialog.close()
                    break
                elif tag_info == tag_name:
                    self.tags[self.current_file].remove(tag_info)
                    self.statusBar.showMessage(f'已删除标签 "{tag_name}"')
                    dialog.close()
                    break
            if not self.tags[self.current_file]:
                del self.tags[self.current_file]
        else:
            self.statusBar.showMessage('请选择一个要删除的标签')

    def showConversionError(self, error_message, format):
        if error_message == 'Pandoc未安装':
            QMessageBox.critical(self, 'Pandoc未安装', 'Pandoc未安装，转换功能不可用。请安装Pandoc以启用转换功能。<br><br><font color="red">下载链接: <a href="https://pandoc.org/installing.html">https://pandoc.org/installing.html</a></font>', QMessageBox.Ok)
            self.statusBar.showMessage('转换失败: Pandoc未安装')
        else:
            QMessageBox.warning(self, '转换错误', error_message, QMessageBox.Ok)
            self.statusBar.showMessage('转换失败: 发生错误')

if __name__ == '__main__':
    import ctypes
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)  # 隐藏控制台窗口
    app = QApplication(sys.argv)
    ex = MarkdownReader()
    ex.show()
    # 检查命令行参数中是否有文件路径
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        if os.path.exists(file_path) and file_path.endswith('.md'):
            ex.openFile(file_path)
    sys.exit(app.exec())
